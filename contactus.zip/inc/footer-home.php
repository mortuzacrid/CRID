
    <script src="js/jquery.js"></script>
    <script src="js/plugins.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prettyPhoto/3.1.6/js/jquery.prettyPhoto.min.js"></script>
    <script src="js/init.js"></script>
    <script type="text/javascript" src="js/index-others.js"></script>
</body>
</html>
