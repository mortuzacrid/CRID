
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>© 2019 CRID DAM Robotic labs. All Rights Reserved.</p>
                </div>
                <div class="col-md-6">
                     <ul class="pull-right">
                            <li><a id="gototop" class="gototop" href="#"><i class="fa fa-chevron-up"></i></a></li>
                            <!--#gototop-->
                        </ul>
                </div>
            </div>
            

        </div>
    </footer>

    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/js/lightbox.min.js"></script>
    <script src="js/others.js"></script>

</body>
</html>
