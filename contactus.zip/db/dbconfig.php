<?php
	include 'const.php';
	$con = mysqli_connect(HOST,USER,PASS,DBNAME);

/*	if ($con) {
		echo "CONNECTED";
	} else {
		echo "NOT CONNECTED";
	}*/